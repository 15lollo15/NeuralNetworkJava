package reti.neurali;

public class Matrix{
    private int col;
    private int row;
    private double[][] matrix;
    
    public Matrix(int col, int row) {
        this.col = col;
        this.row = row;
        matrix = new double[row][];
        for(int i = 0; i<row; i++)
            matrix[i] = new double[col];
    }
    
    public Matrix(double[] array){
        this(array.length, 1);
        for(int i = 0; i<row; i++)
            matrix[i][0] = array[i];
    }
    
    public Matrix(Matrix m){
        this(m.row, m.col);
        for(int i = 0; i<row; i++)
            for(int j = 0; j<col; j++)
                matrix[i][j] = m.matrix[i][j];
    }
    
    @Override
    public String toString(){
        String s = "";
        for(int i = 0; i<row; i++){
            for(int j = 0; j<col; j++){
                s += matrix[i][j] + " ";
            }
            s += "\n";
        }
        return s;
    }

    public int getCol() {
        return col;
    }

    public int getRow() {
        return row;
    }
    
    public double getAt(int r, int c){
        if(r > row || r < 0 || c > col || c < 0)
            throw new MatrixOutOfBoundException();
        return matrix[r][c];
    }
    
    public void setAt(int r, int c, double item){
        if(r > row || r < 0 || c > col || c < 0)
            throw new MatrixOutOfBoundException();
        matrix[r][c] = item;
    }
    
    public static Matrix multiplication(Matrix m1, Matrix m2){
        if(m1.col != m2.row)
            return null;
        Matrix m3 = new Matrix(m1.row, m2.col);
        
        for(int i = 0; i < m3.row; i++){
            for(int j = 0; j < m3.col; j++){
                int sum = 0;
                for(int k = 0; k < m1.col; k++)
                    sum += m1.matrix[i][k] * m2.matrix[k][j];
                m3.matrix[i][j] = sum;
            }
        }
        
        return m3;
    }
    
    public void randomize(){
        for(int i = 0; i<row; i++){
            for(int j = 0; j<col; j++){
                matrix[i][j] = Math.random();
            }
        }
    }
    
    public double[] toArray(){
        double[] array = new double[row*col];
        
        int k = 0;
        for(int i = 0; i<row; i++){
            for(int j = 0; j<col; j++){
                array[k++] = matrix[i][j];
            }
        }
        
        return array;
    }
    
    public void add(Matrix m){
        if(m.row != row || m.col != col)
            return;
        for(int i = 0; i<row; i++)
            for(int j = 0; j<col; j++)
                matrix[i][j] += m.matrix[i][j]; 
    }
    
    public void multiply(double n){
        for(int i = 0; i<row; i++)
            for(int j = 0; j<col; j++)
                matrix[i][j] *= n;
    }
    
    public static Matrix subtract(Matrix m1, Matrix m2){
        if(m1.row != m2.row || m1.col != m2.col)
            return null;
        Matrix m3 = new Matrix(m1.row, m2.col);
        
        for(int i = 0; i<m3.row ; i++){
            for(int j = 0; j<m3.col; j++)
                m3.matrix[i][j] = m1.matrix[i][j] - m2.matrix[i][j];
        }
        return m3;
    }
    
    public static Matrix transpose(Matrix m){
        Matrix m2 = new Matrix(m.col, m.row);
        
        for(int i = 0; i < m2.row; i++)
            for(int j = 0; j<m2.col; j++)
                m2.matrix[i][j] = m.matrix[j][i];
        
        return m2;
    }
}
