/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reti.neurali;

/**
 *
 * @author Lorenzo
 */
public class RetiNeurali {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Matrix m1 = new Matrix(2,2);
        Matrix m2 = new Matrix(2,2);
        
        m1.setAt(0, 0, 1);
        m1.setAt(0, 1, 2);
        m1.setAt(1, 0, 3);
        m1.setAt(1, 1, 4);
        
        m2.setAt(0, 0, 5);
        m2.setAt(0, 1, 6);
        m2.setAt(1, 0, 7);
        m2.setAt(1, 1, 8);
        
        System.out.println(Matrix.multiplication(m1, m2));
    }
    
}
